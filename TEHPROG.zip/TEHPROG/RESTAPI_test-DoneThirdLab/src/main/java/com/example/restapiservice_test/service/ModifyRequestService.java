package com.example.restapiservice_test.service;

import com.example.restapiservice_test.model.Request;

public interface ModifyRequestService {
    void modifyRq (Request request);
}
