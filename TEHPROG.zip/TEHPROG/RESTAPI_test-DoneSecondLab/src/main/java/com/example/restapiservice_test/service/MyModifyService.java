package com.example.restapiservice_test.service;

import com.example.restapiservice_test.model.Response;

public interface MyModifyService {
    Response modify(Response response);
}
