package com.example.testthymeleafwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestThymeleafWebappApplicationTests {

    @Test
    void contextLoads() {
    }

}
