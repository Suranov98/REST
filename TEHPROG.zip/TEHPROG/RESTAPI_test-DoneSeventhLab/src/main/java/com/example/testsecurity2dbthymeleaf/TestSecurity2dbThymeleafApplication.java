package com.example.testsecurity2dbthymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSecurity2dbThymeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestSecurity2dbThymeleafApplication.class, args);
    }

}
