package com.example.testsecurity2dbthymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSecurity2dbThymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}
