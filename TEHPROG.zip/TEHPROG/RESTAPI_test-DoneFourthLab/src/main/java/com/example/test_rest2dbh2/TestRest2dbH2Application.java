package com.example.test_rest2dbh2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestRest2dbH2Application {

    public static void main(String[] args) {
        SpringApplication.run(TestRest2dbH2Application.class, args);
    }

}
