package com.example.test_rest2dbh2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestRest2dbH2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
