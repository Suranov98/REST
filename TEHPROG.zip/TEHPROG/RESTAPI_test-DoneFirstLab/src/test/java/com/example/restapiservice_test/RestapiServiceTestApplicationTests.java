package com.example.restapiservice_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiServiceTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
